<?php
	// ================================================
	// iFmup - File Upload WYSIWYG
	// ================================================
	// iFmup
	// ================================================
	// Developed: dimworks.org
	// Copyright: dimworks.org
	// (c)2013 All rights reserved.
	// ================================================
	// Revision: 0.1.1                 Date: 10/05/2013
	// ================================================

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>iFmup by Dim Wroks (dimworks.org)</title>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=es/MX">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
<style type="text/css">
<!--
    @import url("css/style.css");
-->
</style>

</head>
<body>
<table width="100%" border="0">
<tr><td align="center"><a href="fileupload.php"><img src="images/img_po.gif" alt='Subir Imagenes'><br>Subir Imagenes</a></td>
<td align="center"><a href="ibrowser.php" ><img src="images/img_in.gif" alt='Insertar Imagenes'><br>Insertar Imagen</a></td>
<td align="center"><a href="about.php" ><img src="images/ib.gif" alt='Acerca de...'><br>Acerca de...</a></td></tr>
</table><hr><br><center>
<table border="0">
<tr>
<td align="right">Autor:</td><td align="left">Oliver Leuyim Angel</td>
</tr><tr>
<td align="right">Fecha:</td><td align="left">15/05/2013</td>
</tr><tr>
<td align="right">Version:</td><td align="left">0.1.1</td>
</tr><tr>
<td align="right">Pagina:</td><td align="left">Dimworks.org</td>
</tr><tr>
<td align="right">Plug-in:</td><td align="left">iFmup</td>
</tr>
</table></center>
</body>
</html>