<?php
declare(strict_types=1);

// --- CLAVE SECRETA COMPARTIDA PARA HMAC ---
// Definida según tu instrucción directa.
define('IBROWSER_SHARED_SECRET_KEY', ($_COOKIE["REMCURUS"] ?? '') . ($_COOKIE["REMCURPAS"] ?? '') . "DIM WORKS KERNEL");

// --- CONFIGURACIÓN DE RUTAS PRINCIPALES ---
// Estas son las rutas base. El contexto del usuario ('ctx' del token) se añadirá a las rutas de usuario.

// Ruta física base donde se almacenarán todas las carpetas de los usuarios.
// Ejemplo: /var/www/html/uploads/members/
// El 'ctx' del token se añadirá a esto, ej: /var/www/html/uploads/members/usuario123/
define('USER_GALLERIES_BASE_PHYSICAL', $_SERVER['DOCUMENT_ROOT'] . "/uploads/members");

// URL base correspondiente a USER_GALLERIES_BASE_PHYSICAL.
// Ejemplo: /uploads/members
// El 'ctx' del token se añadirá, ej: /uploads/members/usuario123/
define('USER_GALLERIES_BASE_URL', "/uploads/members");

// Ruta física absoluta para la galería general compartida.
// Ejemplo: /var/www/html/uploads/mce/
define('GENERAL_GALLERY_PHYSICAL_PATH', $_SERVER['DOCUMENT_ROOT'] . "/uploads/mce");

// URL base correspondiente a GENERAL_GALLERY_PHYSICAL_PATH.
// Ejemplo: /uploads/mce
define('GENERAL_GALLERY_URL', "/uploads/mce");

if (!defined('GENERAL_GALLERY_PATH_CREATED_CHECK')) {
    if (!is_dir(GENERAL_GALLERY_PHYSICAL_PATH)) {
        if (!@mkdir(GENERAL_GALLERY_PHYSICAL_PATH, 0755, true) && !is_dir(GENERAL_GALLERY_PHYSICAL_PATH)) {
            error_log("CRITICAL ERROR (extdata.php): Failed to create General Gallery directory at: " . GENERAL_GALLERY_PHYSICAL_PATH . ". Check parent directory permissions and path configuration.");
        } else {
            error_log("INFO (extdata.php): General Gallery directory verified/created at: " . GENERAL_GALLERY_PHYSICAL_PATH);
        }
    }
    define('GENERAL_GALLERY_PATH_CREATED_CHECK', true);
}

// Ruta al archivo SQLite para la galería general.
// La carpeta 'data' se asume al mismo nivel que extdata.php.
define('SQLITE_GENERAL_GALLERY_DB_FILE', __DIR__ . '/data/general_gallery.sqlite');


if (!function_exists('base64_url_decode')) {
    function base64_url_decode(string $data): string {
        return base64_decode(strtr($data, '-_', '+/'));
    }
}

if (!function_exists('base64_url_encode')) {
    function base64_url_encode(string $data): string {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
}

if (!function_exists('get_general_gallery_db_connection')) {
    function get_general_gallery_db_connection() {
        static $db_conn = null;
        if ($db_conn === null) {
            try {
                $dbFile = SQLITE_GENERAL_GALLERY_DB_FILE;
                $dbDir = dirname($dbFile);

                if (!is_dir($dbDir)) {
                    if (!@mkdir($dbDir, 0755, true) && !is_dir($dbDir)) {
                        error_log("Error Crítico: No se pudo crear el directorio de datos: " . $dbDir . " para el archivo DB: " . $dbFile);
                        return null;
                    }
                }
                
                $dbNeedsSetup = !file_exists($dbFile);

                $db_conn = new PDO('sqlite:' . $dbFile);
                $db_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $db_conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
                $db_conn->exec('PRAGMA journal_mode = WAL;');
                $db_conn->exec('PRAGMA synchronous = NORMAL;');
                $db_conn->exec('PRAGMA foreign_keys = ON;');

                if ($dbNeedsSetup || $db_conn->query("SELECT name FROM sqlite_master WHERE type='table' AND name='general_images'")->fetchColumn() === false) {
                    $db_conn->exec("CREATE TABLE IF NOT EXISTS general_images (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        filename TEXT UNIQUE NOT NULL COLLATE NOCASE,
                        title TEXT,
                        alt_text TEXT,
                        date_added INTEGER,
                        filepath TEXT 
                    )");
                    $db_conn->exec("CREATE INDEX IF NOT EXISTS idx_general_images_filename ON general_images (filename)");
                    $db_conn->exec("CREATE INDEX IF NOT EXISTS idx_general_images_date_added ON general_images (date_added)");
                    error_log("iFmup: BD SQLite para galería general y tabla 'general_images' verificadas/creadas en " . $dbFile);
                }
            } catch (PDOException $e) {
                error_log("SQLite Connection/Setup Error en extdata.php: " . $e->getMessage());
                return null;
            }
        }
        return $db_conn;
    }
}

if (!function_exists('verify_ibrowser_access_token')) {
    function verify_ibrowser_access_token(?string $token): ?array {
        if ($token === null || empty($token)) {
            error_log('Access Token Verify: No token provided.');
            return null;
        }
        $parts = explode('.', $token);
        if (count($parts) !== 2) {
            error_log('Access Token Verify: Token format invalid.');
            return null;
        }
        $encodedPayload = $parts[0];
        $encodedSignatureFromToken = $parts[1];

        $expectedSignatureBinary = hash_hmac('sha256', $encodedPayload, IBROWSER_SHARED_SECRET_KEY, true);
        $signatureFromTokenBinary = base64_url_decode($encodedSignatureFromToken);

        if (!hash_equals($expectedSignatureBinary, $signatureFromTokenBinary)) {
            error_log('Access Token Verify: Token signature mismatch. Check IBROWSER_SHARED_SECRET_KEY consistency or token tampering.');
            return null;
        }
        $payloadJson = base64_url_decode($encodedPayload);
        $payload = json_decode($payloadJson, true);

        if ($payload === null || !isset($payload['exp']) || !isset($payload['ctx'])) {
            error_log('Access Token Verify: Token payload malformed or missing fields (exp, ctx). Payload: ' . $payloadJson);
            return null;
        }
        if (time() > $payload['exp']) {
            error_log('Access Token Verify: Token expired. Expiry: ' . date('Y-m-d H:i:s', (int)$payload['exp']) . ', Current: ' . date('Y-m-d H:i:s', time()));
            return null;
        }
        
        $payload['ctx'] = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$payload['ctx']);
        if (empty($payload['ctx'])) {
            error_log('Access Token Verify: Context (ctx) from token is empty after sanitization.');
            return null;
        }
        return $payload;
    }
}
?>