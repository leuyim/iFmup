<?php
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once __DIR__ . '/extdata.php';

$accessToken = $_POST['access_token'] ?? null;
$tokenPayload = verify_ibrowser_access_token($accessToken);

if ($tokenPayload === null) {
    http_response_code(403);
    error_log('UPLOAD.PHP: Failed HMAC token validation.');
    // No redirigir aquí, simplemente morir para evitar bucles si el token se pierde.
    die('UPLOAD_ERR_FATAL: Acceso Denegado. Token HMAC inválido.');
}

$csrfTokenFromField = $_POST['csrf_token_field'] ?? '';
$csrfTokenFromCookie = $_COOKIE['csrf_form_token_fu'] ?? '';

if (empty($csrfTokenFromField) || empty($csrfTokenFromCookie) || !hash_equals($csrfTokenFromCookie, $csrfTokenFromField)) {
    http_response_code(403);
    error_log('UPLOAD.PHP: Failed CSRF token validation.');
    die('UPLOAD_ERR_FATAL: Acceso Denegado. Token CSRF inválido.');
}

$userContextFromToken = $tokenPayload['ctx'];
$protocol_up = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
$host_up = $_SERVER['HTTP_HOST'] ?? 'localhost';

$appBaseUrlForRedirect = rtrim(str_ireplace(basename(__FILE__), '', $protocol_up . "://".$host_up.dirname($_SERVER['PHP_SELF'])), '/');

$userBaseGalleryPhysicalPath = rtrim(USER_GALLERIES_BASE_PHYSICAL, '/\\') . DIRECTORY_SEPARATOR . $userContextFromToken;
$physicalGeneralGalleryPath = rtrim(GENERAL_GALLERY_PHYSICAL_PATH, '/\\');

if (!is_dir($userBaseGalleryPhysicalPath)) {
    if (!@mkdir($userBaseGalleryPhysicalPath, 0755, true) && !is_dir($userBaseGalleryPhysicalPath)) {
        error_log('UPLOAD.PHP: Critical error creating user base directory: ' . $userBaseGalleryPhysicalPath);
        // No se puede continuar si el directorio base del usuario no se puede crear.
        // Construir manualmente la URL de redirección con error.
        $errorParams = http_build_query([
            'access_token' => $accessToken,
            'status_count' => 1,
            'msg_type_0' => 'error',
            'msg_text_0' => 'Error crítico: No se pudo crear el directorio base del usuario.'
        ]);
        header('Location: fileupload.php?' . $errorParams);
        exit;
    }
}

function sanitize_name_component_up(string $name, bool $isFilename = false): string {
    $name = trim(mb_strtolower($name, 'UTF-8'));
    $name = str_replace(' ', '_', $name);
    $pattern = $isFilename ? '/[^a-z0-9_.-]/' : '/[^a-z0-9_-]/';
    $name = preg_replace($pattern, '', $name);
    $name = preg_replace('/_{2,}/', '_', $name);
    if ($isFilename) $name = preg_replace('/\.{2,}/', '.', $name);
    $name = trim($name, '_.-');
    if (empty($name) || $name === '.' || $name === '..') {
        return 'nombre_invalido_' . bin2hex(random_bytes(3));
    }
    if ($isFilename) {
        $parts = explode('.', $name);
        if (count($parts) > 1) {
            $ext = array_pop($parts);
            $base = implode('_', $parts);
            if(empty($base)) $base = "archivo_sin_nombre";
            $name = $base . '.' . $ext;
        } elseif (empty($parts[0])) {
            return 'nombre_archivo_invalido_' . bin2hex(random_bytes(3));
        }
    }
    return $name;
}

function resolve_safe_path_final_up(string $absoluteBaseDir, string $relativeUserPath, bool $mustExist = true, bool $isDirOnlyCheck = false): ?string {
    $realBaseDir = realpath($absoluteBaseDir);
    if ($realBaseDir === false) {
        error_log("UP_RESOLVE_FINAL: El directorio base absoluto '{$absoluteBaseDir}' no existe o no es accesible.");
        return null;
    }
    $cleanRelativePath = '';
    if (!empty($relativeUserPath)) {
        $parts = explode('/', str_replace('\\', '/', $relativeUserPath));
        $safeParts = [];
        foreach ($parts as $part) {
            if ($part === '..') { error_log("UP_RESOLVE_FINAL: Intento de path traversal '..' en '{$relativeUserPath}'."); return null; }
            $sanitizedPart = sanitize_name_component_up($part, false);
            if ($sanitizedPart !== '' && $sanitizedPart !== '.' && $sanitizedPart !== 'nombre_invalido') {
                $safeParts[] = $sanitizedPart;
            }
        }
        $cleanRelativePath = implode(DIRECTORY_SEPARATOR, $safeParts);
    }
    $fullCandidatePath = $realBaseDir . (empty($cleanRelativePath) ? '' : DIRECTORY_SEPARATOR . $cleanRelativePath);

    if ($mustExist) {
        $realFullPath = realpath($fullCandidatePath);
        if ($realFullPath === false || strpos($realFullPath, $realBaseDir) !== 0) {
            error_log("UP_RESOLVE_FINAL: El path '{$fullCandidatePath}' (mustExist) es inválido o está fuera de base '{$realBaseDir}'. Realpath: " . var_export($realFullPath,true));
            return null;
        }
        if ($isDirOnlyCheck && !is_dir($realFullPath)) { error_log("UP_RESOLVE_FINAL: Se esperaba un directorio, pero '{$realFullPath}' no lo es."); return null; }
        return $realFullPath;
    } else {
        $parentDirOfCandidate = dirname($fullCandidatePath);
        $realParentDir = realpath($parentDirOfCandidate);
        if ($realParentDir === false || strpos($realParentDir, $realBaseDir) !== 0) {
            error_log("UP_RESOLVE_FINAL: El directorio padre de '{$fullCandidatePath}' es inválido o está fuera de la base '{$realBaseDir}'. Padre resuelto: " . var_export($realParentDir, true));
            return null;
        }
        if (basename($fullCandidatePath) === '.' || basename($fullCandidatePath) === '..') {error_log("UP_RESOLVE_FINAL: Nombre de archivo/carpeta final inválido."); return null;}
        return $fullCandidatePath;
    }
}

function safe_delete_directory_recursive_up(string $dirPath): bool {
    if (!is_dir($dirPath)) return true;
    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dirPath, RecursiveDirectoryIterator::SKIP_DOTS | RecursiveDirectoryIterator::CURRENT_AS_PATHNAME),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iterator as $filePathname) {
            if (is_dir($filePathname) && !is_link($filePathname)) {
                if(!@rmdir($filePathname)) { error_log("UP_DELETE_REC: Falló rmdir en " . $filePathname); return false; }
            } else {
                if(!@unlink($filePathname)) { error_log("UP_DELETE_REC: Falló unlink en " . $filePathname); return false; }
            }
        }
        return @rmdir($dirPath);
    } catch (Exception $e) {
        error_log("UP_DELETE_REC: Excepción borrando directorio {$dirPath}: " . $e->getMessage());
        return false;
    }
}

function resize_image_up(string $sourcePath, string $destinationPath, int $maxDimension): bool {
    $imageInfo = @getimagesize($sourcePath);
    if (!$imageInfo) { error_log("ResizeUP: Inválido getimagesize para {$sourcePath}"); return false; }
    list($origWidth, $origHeight, $imageType) = $imageInfo;
    if ($origWidth == 0 || $origHeight == 0) { error_log("ResizeUP: Dimensiones inválidas para {$sourcePath}"); return false; }

    $sourceImage = null;
    switch ($imageType) {
        case IMAGETYPE_JPEG: $sourceImage = @imagecreatefromjpeg($sourcePath); break;
        case IMAGETYPE_PNG:  $sourceImage = @imagecreatefrompng($sourcePath);  break;
        case IMAGETYPE_GIF:  $sourceImage = @imagecreatefromgif($sourcePath);  break;
        case IMAGETYPE_WEBP: if (function_exists('imagecreatefromwebp')) $sourceImage = @imagecreatefromwebp($sourcePath); break;
        case IMAGETYPE_AVIF: if (function_exists('imagecreatefromavif')) $sourceImage = @imagecreatefromavif($sourcePath); break;
        default: error_log("ResizeUP: Tipo de imagen no soportado {$imageType} para {$sourcePath}"); return false;
    }
    if (!$sourceImage) { error_log("ResizeUP: No se pudo crear recurso de imagen desde {$sourcePath}"); return false; }

    if ($origWidth <= $maxDimension && $origHeight <= $maxDimension) {
        imagedestroy($sourceImage);
        if ($sourcePath !== $destinationPath && !@copy($sourcePath, $destinationPath)) {
             error_log("ResizeUP: No se redimensionó, pero falló al copiar {$sourcePath} a {$destinationPath}"); return false;
        }
        return true;
    }
    $ratio = $origWidth / $origHeight;
    if ($origWidth > $origHeight) {
        $newWidth = $maxDimension; $newHeight = (int)round($newWidth / $ratio);
    } else {
        $newHeight = $maxDimension; $newWidth = (int)round($newHeight * $ratio);
    }
    if ($newWidth < 1) $newWidth = 1; if ($newHeight < 1) $newHeight = 1;

    $resizedImage = @imagecreatetruecolor($newWidth, $newHeight);
    if (!$resizedImage) { imagedestroy($sourceImage); error_log("ResizeUP: imagecreatetruecolor falló."); return false;}

    if ($imageType == IMAGETYPE_PNG || $imageType == IMAGETYPE_GIF || $imageType == IMAGETYPE_WEBP || $imageType == IMAGETYPE_AVIF) {
        @imagealphablending($resizedImage, false); @imagesavealpha($resizedImage, true);
        $transparent = @imagecolorallocatealpha($resizedImage, 255, 255, 255, 127);
        if ($transparent !== false) @imagefilledrectangle($resizedImage, 0, 0, $newWidth, $newHeight, $transparent);
    }
    
    if (!@imagecopyresampled($resizedImage, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $origWidth, $origHeight)) {
         imagedestroy($sourceImage); imagedestroy($resizedImage); error_log("ResizeUP: imagecopyresampled falló."); return false;
    }
    $success = false; $qualityJpeg = 85; $qualityPng = 7; $qualityWebp = 85; $qualityAvif = 60;

    if ((file_exists($destinationPath) && !is_writable($destinationPath)) || !is_writable(dirname($destinationPath))) {
        error_log("ResizeUP: Permisos de escritura incorrectos para {$destinationPath}");
        imagedestroy($sourceImage); imagedestroy($resizedImage); return false;
    }
    switch ($imageType) {
        case IMAGETYPE_JPEG: $success = @imagejpeg($resizedImage, $destinationPath, $qualityJpeg); break;
        case IMAGETYPE_PNG:  $success = @imagepng($resizedImage, $destinationPath, $qualityPng);  break;
        case IMAGETYPE_GIF:  $success = @imagegif($resizedImage, $destinationPath);  break;
        case IMAGETYPE_WEBP: if (function_exists('imagewebp')) $success = @imagewebp($resizedImage, $destinationPath, $qualityWebp); break;
        case IMAGETYPE_AVIF: if (function_exists('imageavif')) $success = @imageavif($resizedImage, $destinationPath, $qualityAvif); break;
    }
    imagedestroy($sourceImage); imagedestroy($resizedImage);
    if (!$success) error_log("ResizeUP: Falló al guardar imagen redimensionada en {$destinationPath}");
    return $success;
}

$action = $_POST['action'] ?? '';
$statusMessages = [];
$uploadedFilesInfoForRedirect = [];

switch ($action) {
    case 'create_folder':
        $newFolderNameRaw = $_POST['new_folder_name'] ?? '';
        $baseRelativePathRaw = $_POST['base_relative_path'] ?? ''; // Para crear dentro de una subcarpeta del usuario
        $newFolderName = sanitize_name_component_up($newFolderNameRaw, false);
        
        $finalBaseRelativePath = ''; 
        if(!empty($baseRelativePathRaw)){
            $baseParts = explode('/', str_replace('\\', '/', $baseRelativePathRaw));
            $sanitizedBaseParts = array_map(fn($part) => sanitize_name_component_up($part, false), $baseParts);
            $finalBaseRelativePath = implode(DIRECTORY_SEPARATOR, array_filter($sanitizedBaseParts));
        }

        if (empty($newFolderName) || $newFolderName === 'nombre_invalido') {
            $statusMessages[] = ['type' => 'error', 'text' => 'Nombre de carpeta inválido.']; break;
        }
        $parentDir = resolve_safe_path_final_up($userBaseGalleryPhysicalPath, $finalBaseRelativePath, true, true);
        if ($parentDir === null) {
            $statusMessages[] = ['type' => 'error', 'text' => 'Ruta base para nueva carpeta es inválida.']; break;
        }
        $newFolderPath = $parentDir . DIRECTORY_SEPARATOR . $newFolderName;
        if (file_exists($newFolderPath)) {
            $statusMessages[] = ['type' => 'error', 'text' => 'La carpeta "' . htmlspecialchars($newFolderName) . '" ya existe.'];
        } elseif (!@mkdir($newFolderPath, 0755) && !is_dir($newFolderPath)) {
            $statusMessages[] = ['type' => 'error', 'text' => 'No se pudo crear carpeta "' . htmlspecialchars($newFolderName) . '".'];
        } else {
            $statusMessages[] = ['type' => 'success', 'text' => 'Carpeta "' . htmlspecialchars($newFolderName) . '" creada.'];
        }
        break;

    case 'upload_file':
        if (isset($_FILES['archivos']) && is_array($_FILES['archivos']['name'])) {
            $destinationGalleryType = $_POST['destination_gallery_type'] ?? 'user_root';
            $userSubfolderPathRaw = $_POST['user_subfolder_path'] ?? '';
            $uploadTargetBasePhysicalDir = $userBaseGalleryPhysicalPath;
            $isGeneralGalleryUpload = false;
            $destinationDirRelativeClean = '';

            if ($destinationGalleryType === 'general') {
                $uploadTargetBasePhysicalDir = $physicalGeneralGalleryPath;
                $isGeneralGalleryUpload = true;
            } elseif ($destinationGalleryType === 'user_subfolder') {
                $parts = explode('/', str_replace('\\', '/', $userSubfolderPathRaw));
                $sanitizedParts = array_map(fn($part) => sanitize_name_component_up($part, false), $parts);
                $destinationDirRelativeClean = implode(DIRECTORY_SEPARATOR, array_filter($sanitizedParts));
            }

            $uploadDestinationDirValidated = resolve_safe_path_final_up($uploadTargetBasePhysicalDir, $destinationDirRelativeClean, true, true);

            if ($uploadDestinationDirValidated === null || !is_dir($uploadDestinationDirValidated) || !is_writable($uploadDestinationDirValidated)) {
                $statusMessages[] = ['type' => 'error', 'text' => 'Directorio destino inválido o sin permisos.'];
                break;
            }

            $filesToProcess = [];
            foreach ($_FILES['archivos']['name'] as $i => $name) {
                if ($_FILES['archivos']['error'][$i] === UPLOAD_ERR_OK) {
                    $filesToProcess[] = ['name' => $name, 'type' => $_FILES['archivos']['type'][$i], 'tmp_name' => $_FILES['archivos']['tmp_name'][$i], 'error' => $_FILES['archivos']['error'][$i], 'size' => $_FILES['archivos']['size'][$i]];
                } else { $statusMessages[] = ['type' => 'error', 'text' => 'Error subiendo "'.htmlspecialchars($name).'": Código '.$_FILES['archivos']['error'][$i]]; }
            }

            foreach($filesToProcess as $file) {
                $originalFilename = basename($file['name']);
                $sanitizedFilename = sanitize_name_component_up($originalFilename, true);
                $fileExtension = strtolower(pathinfo($sanitizedFilename, PATHINFO_EXTENSION));
                $tmpFilePath = $file['tmp_name'];

                $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif']; $allowedMimeTypes = ['image/jpeg', 'image/pjpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif'];
                $finfo = finfo_open(FILEINFO_MIME_TYPE); $mimeType = finfo_file($finfo, $tmpFilePath); finfo_close($finfo);

                if (empty($sanitizedFilename) || str_starts_with($sanitizedFilename, 'nombre_invalido') || !in_array($fileExtension, $allowedExtensions) || !in_array($mimeType, $allowedMimeTypes)) {
                    $statusMessages[] = ['type' => 'error', 'text' => 'Tipo/nombre inválido: ' . htmlspecialchars($originalFilename)]; @unlink($tmpFilePath); continue;
                }
                if ($file['size'] > 10 * 1024 * 1024) { $statusMessages[] = ['type' => 'error', 'text' => 'Archivo grande: ' . htmlspecialchars($originalFilename)]; @unlink($tmpFilePath); continue; }

                $targetFilePath = $uploadDestinationDirValidated . DIRECTORY_SEPARATOR . $sanitizedFilename;
                $counter = 1; $filenameWithoutExt = pathinfo($sanitizedFilename, PATHINFO_FILENAME);
                while (file_exists($targetFilePath)) {
                    $targetFilePath = $uploadDestinationDirValidated . DIRECTORY_SEPARATOR . $filenameWithoutExt . '_' . $counter++ . '.' . $fileExtension;
                }
                $finalUploadedFilenameOnDisk = basename($targetFilePath);
                
                if (move_uploaded_file($tmpFilePath, $targetFilePath)) {
                    @chmod($targetFilePath, 0644);
                    $statusMessages[] = ['type' => 'success', 'text' => 'Archivo "' . htmlspecialchars($finalUploadedFilenameOnDisk) . '" subido.'];
                    $uploadedFilesInfoForRedirect[] = $finalUploadedFilenameOnDisk;

                    $resizeMaxDimRaw = trim($_POST['resize_max_dimension'] ?? '');
                    if ($resizeMaxDimRaw !== '=' && is_numeric($resizeMaxDimRaw) && (int)$resizeMaxDimRaw > 50) {
                        if (resize_image_up($targetFilePath, $targetFilePath, (int)$resizeMaxDimRaw)) {
                             $statusMessages[] = ['type' => 'info', 'text' => '"'.htmlspecialchars($finalUploadedFilenameOnDisk).'" redimensionada.'];
                        } else { $statusMessages[] = ['type' => 'warning', 'text' => '"'.htmlspecialchars($finalUploadedFilenameOnDisk).'" subida, falló redimensión.']; }
                    }
                    
                    if ($isGeneralGalleryUpload) {
                        $dbGeneral = get_general_gallery_db_connection();
                        if ($dbGeneral) {
                            try {
                                $stmt = $dbGeneral->prepare("INSERT OR REPLACE INTO general_images (filename, date_added, alt_text, title, filepath) VALUES (:filename, :date_added, :alt_text, :title, :filepath)");
                                $filenameForDb = $finalUploadedFilenameOnDisk;
                                $filepathInGeneral = ($destinationDirRelativeClean === '') ? '' : $destinationDirRelativeClean; 
                                $stmt->bindValue(':filename', $filenameForDb);
                                $stmt->bindValue(':date_added', time());
                                $stmt->bindValue(':alt_text', pathinfo($filenameForDb, PATHINFO_FILENAME));
                                $stmt->bindValue(':title', pathinfo($filenameForDb, PATHINFO_FILENAME));
                                $stmt->bindValue(':filepath', $filepathInGeneral);
                                $stmt->execute();
                            } catch (PDOException $e) {
                                error_log("Upload.php: Error añadiendo a BD general '" . $filenameForDb . "': " . $e->getMessage());
                                $statusMessages[] = ['type' => 'warning', 'text' => 'Error BD Gral: "'.htmlspecialchars($filenameForDb).'".'];
                            }
                        }
                    }
                } else { $statusMessages[] = ['type' => 'error', 'text' => 'Error al mover: ' . htmlspecialchars($originalFilename)]; }
            }
        } else { $statusMessages[] = ['type' => 'error', 'text' => 'No se recibieron archivos o hubo un error mayor en la subida.']; }
        break;

    case 'delete_folder':
        $folderToDeleteRelativeRaw = $_POST['folder_to_delete_relative'] ?? '';
        $galleryTypeForDelete = $_POST['gallery_type_for_delete'] ?? 'user';

        if ($galleryTypeForDelete !== 'user') {
            $statusMessages[] = ['type' => 'error', 'text' => 'La eliminación de carpetas solo está permitida en "Mi Galería".']; break;
        }
        
        $partsDel = explode('/', str_replace('\\', '/', $folderToDeleteRelativeRaw));
        $sanitizedPartsDel = array_map(fn($part) => sanitize_name_component_up($part, false), $partsDel);
        $folderToDeleteRelative = implode(DIRECTORY_SEPARATOR, array_filter($sanitizedPartsDel));

        if (empty($folderToDeleteRelative) || str_starts_with($folderToDeleteRelative, 'nombre_invalido')) {
            $statusMessages[] = ['type' => 'error', 'text' => 'No se especificó carpeta válida para borrar.']; break;
        }
        $folderPathToDelete = resolve_safe_path_final_up($userBaseGalleryPhysicalPath, $folderToDeleteRelative, true, true);

        if ($folderPathToDelete === null || !is_dir($folderPathToDelete) || $folderPathToDelete === realpath($userBaseGalleryPhysicalPath) ) {
            $statusMessages[] = ['type' => 'error', 'text' => 'Carpeta no encontrada o no se puede borrar: ' . htmlspecialchars($folderToDeleteRelativeRaw)]; break;
        }
        if (safe_delete_directory_recursive_up($folderPathToDelete)) {
            $statusMessages[] = ['type' => 'success', 'text' => 'Carpeta "' . htmlspecialchars($folderToDeleteRelativeRaw) . '" borrada.'];
        } else { $statusMessages[] = ['type' => 'error', 'text' => 'Error al borrar carpeta "' . htmlspecialchars($folderToDeleteRelativeRaw) . '".']; }
        break;
    default:
        $statusMessages[] = ['type' => 'error', 'text' => 'Acción no válida: ' . htmlspecialchars($action)];
        break;
}

$redirectParams = ['access_token' => $accessToken];
if (!empty($statusMessages)) {
    $redirectParams['status_count'] = count($statusMessages);
    foreach($statusMessages as $idx => $msg) {
        $redirectParams['msg_type_'.$idx] = $msg['type'];
        $redirectParams['msg_text_'.$idx] = $msg['text'];
    }
}
if (!empty($uploadedFilesInfoForRedirect)) {
    $redirectParams['uploaded_files_count'] = count($uploadedFilesInfoForRedirect);
    foreach($uploadedFilesInfoForRedirect as $idx => $fname) {
         $redirectParams['uploaded_file_'.$idx] = $fname;
    }
}

$redirectUrl = 'fileupload.php?' . http_build_query($redirectParams);
header('Location: ' . $redirectUrl);
exit;
?>