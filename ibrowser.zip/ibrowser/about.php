<?php
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once __DIR__ . '/extdata.php';

$receivedAccessToken = $_GET['access_token'] ?? null;
$tokenPayload = verify_ibrowser_access_token($receivedAccessToken);

if ($tokenPayload === null) {
    http_response_code(403);
    die('Acceso Denegado. El token de acceso es inválido, ha expirado o no se proporcionó.');
}
$validAccessTokenForLinks = $receivedAccessToken;

// Aunque 'about.php' no maneje contextos de usuario específicos para mostrar archivos,
// el token podría llevar un contexto que, si bien no se usa aquí, es parte del token validado.
// $userContextFromToken = $tokenPayload['ctx']; 

// APP_BASE_URL para construir URLs absolutas si fuera necesario, aunque aquí se usa menos.
$protocol_about = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
define('APP_BASE_URL_ABOUT', rtrim(str_ireplace(basename(__FILE__), '', $protocol_about . "://".$_SERVER["HTTP_HOST"].dirname($_SERVER['PHP_SELF'])), '/'));

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Pragma" content="no-cache">
    <title>Acerca de iFmup - DimWorks</title>
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="css/modern_ibrowser_style.css">
    <style>
        .about-page-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        .about-content-box {
            max-width: 600px;
            width: 100%;
            margin-top: 2rem;
            padding: 2rem;
            background-color: #fff;
            border-radius: 0.375rem; /* Bootstrap-like border-radius */
            box-shadow: 0 0.125rem 0.25rem rgba(0,0,0,.075);
            border: 1px solid #dee2e6;
        }
        .about-content-box h2 {
            text-align: center;
            margin-top: 0;
            margin-bottom: 1.5rem;
            color: #343a40;
            font-size: 1.75rem;
            border-bottom: 1px solid #eee;
            padding-bottom: 0.75rem;
        }
        .about-content-box h2 .fas {
            margin-right: 0.5rem;
        }
        .about-details {
            font-size: 0.95rem;
        }
        .about-details dt {
            font-weight: 600; /* Semibold */
            color: #495057;
            float: left;
            width: 120px;
            clear: left;
            padding-right: 10px;
            text-align: right;
        }
        .about-details dd {
            margin-left: 130px;
            margin-bottom: 0.85rem;
            color: #212529;
        }
        .about-details dd a {
            color: #007bff;
            text-decoration: none;
        }
        .about-details dd a:hover {
            text-decoration: underline;
        }
        .logo-container {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .logo-container img {
            max-width: 100px; /* Ajusta el tamaño del logo si tienes uno */
            height: auto;
        }
    </style>
</head>
<body>
    <header class="ifmup-header">
        <nav>
            <ul>
                <li><a href="fileupload.php?access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>" title="Subir Imágenes"><i class="fas fa-upload"></i> <span>Subir</span></a></li>
                <li><a href="ibrowser.php?access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>" title="Galería de Imágenes"><i class="fas fa-images"></i> <span>Galería</span></a></li>
                <li><a href="about.php?access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>" title="Acerca de..." class="active"><i class="fas fa-info-circle"></i> <span>Acerca</span></a></li>
            </ul>
        </nav>
    </header>

    <main class="ifmup-container about-page-container">
        <div class="about-content-box">
            <div class="logo-container">
                </div>
            <h2><i class="fas fa-info-circle"></i> Acerca de iFmup</h2>
            <dl class="about-details">
                <dt>Autor:</dt>
                <dd>Oliver Leuyim Angel</dd>

                <dt>Copyright:</dt>
                <dd>&copy; 2013-<?php echo date("Y"); ?> Dimworks.org</dd>

                <dt>Versión Original:</dt>
                <dd>0.1.3 (Fecha: 31/01/2018)</dd>
                
                <dt>Versión Actual:</dt>
                <dd>Refactorización <?php echo date("Y"); ?> versión: 2.0</dd>

                <dt>Sitio Web:</dt>
                <dd><a href="http://dimworks.org" target="_blank" rel="noopener noreferrer">Dimworks.org</a></dd>

                <dt>Nombre Plug-in:</dt>
                <dd>iFmup (File Manager Upload)</dd>

                <dt>Descripción:</dt>
                <dd>Gestor de archivos y subida de imágenes, diseñado para una integración sencilla con editores WYSIWYG, ahora modernizado para mayor seguridad y una mejor experiencia de usuario.</dd>
            </dl>
        </div>
    </main>

</body>
</html>