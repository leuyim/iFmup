<?php
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once __DIR__ . '/extdata.php';

$receivedAccessToken = $_GET['access_token'] ?? null;
$tokenPayload = verify_ibrowser_access_token($receivedAccessToken);

if ($tokenPayload === null) {
    http_response_code(403);
    die('Acceso Denegado. El token de acceso es inválido, ha expirado o no se proporcionó.');
}
$validAccessTokenForLinks = $receivedAccessToken;
$userContextFromToken = $tokenPayload['ctx'];

$protocol_ib = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
$host_ib = $_SERVER['HTTP_HOST'] ?? 'localhost';

define('APP_BASE_URL_IB', rtrim(str_ireplace(basename(__FILE__), '', $protocol_ib . "://".$host_ib.dirname($_SERVER['PHP_SELF'])), '/'));

define('USER_GALLERIES_BASE_PHYSICAL_IB', rtrim(USER_GALLERIES_BASE_PHYSICAL, '/\\'));
define('USER_GALLERIES_BASE_URL_IB', rtrim(USER_GALLERIES_BASE_URL, '/'));

define('CURRENT_USER_GALLERY_PHYSICAL_PATH_IB', USER_GALLERIES_BASE_PHYSICAL_IB . DIRECTORY_SEPARATOR . $userContextFromToken);
define('CURRENT_USER_GALLERY_URL_IB', $protocol_ib . '://' . $host_ib . USER_GALLERIES_BASE_URL_IB . '/' . $userContextFromToken);

if (!is_dir(CURRENT_USER_GALLERY_PHYSICAL_PATH_IB)) {
    if (!@mkdir(CURRENT_USER_GALLERY_PHYSICAL_PATH_IB, 0755, true) && !is_dir(CURRENT_USER_GALLERY_PHYSICAL_PATH_IB)) {
        http_response_code(500);
        die('Error: No se pudo crear el directorio de la galería del usuario: ' . htmlspecialchars($userContextFromToken));
    }
}

define('PHYSICAL_GENERAL_GALLERY_PATH_IB', rtrim(GENERAL_GALLERY_PHYSICAL_PATH, '/\\'));
define('GENERAL_GALLERY_URL_IB', $protocol_ib . '://' . $host_ib . GENERAL_GALLERY_URL);


function getCurrentRelativePath_ib(string $userBaseDir): string {
    $relativePath = '';
    if (isset($_GET['dir']) && is_string($_GET['dir'])) {
        $relativePath = trim($_GET['dir'], '/\\');
        $relativePath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $relativePath);
        $parts = explode(DIRECTORY_SEPARATOR, $relativePath);
        $safeParts = [];
        foreach ($parts as $part) {
            if ($part === '..' && count($safeParts) > 0) {
                array_pop($safeParts);
            } elseif ($part !== '' && $part !== '.' && $part !== '..') {
                $safeParts[] = $part;
            }
        }
        $relativePath = implode(DIRECTORY_SEPARATOR, $safeParts);
    }
    $fullResolvedPath = realpath($userBaseDir . DIRECTORY_SEPARATOR . $relativePath);
    if ($fullResolvedPath === false || strpos($fullResolvedPath, realpath($userBaseDir)) !== 0) {
        return '';
    }
    return trim(substr($fullResolvedPath, strlen(realpath($userBaseDir))), DIRECTORY_SEPARATOR);
}

$currentRelativePath_ib = getCurrentRelativePath_ib(CURRENT_USER_GALLERY_PHYSICAL_PATH_IB);
$currentFullPath_ib = CURRENT_USER_GALLERY_PHYSICAL_PATH_IB . (empty($currentRelativePath_ib) ? '' : DIRECTORY_SEPARATOR . $currentRelativePath_ib);
$currentDisplayPath_ib = '/' . str_replace(DIRECTORY_SEPARATOR, '/', $currentRelativePath_ib);

function getDirectoryContents_ib(string $path, string $baseUserPath, string $baseUserUrl): array {
    $directories = [];
    $files = [];
    $allowedImageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif'];
    try {
        if (!is_dir($path) || !is_readable($path)) {
            error_log("Error al leer directorio (usuario): Ruta no válida o sin permisos {$path}");
            return ['directories' => [], 'files' => []];
        }
        $iterator = new DirectoryIterator($path);
        foreach ($iterator as $fileInfo) {
            if ($fileInfo->isDot()) continue;
            $itemName = $fileInfo->getFilename();
            $itemRealPath = $fileInfo->getRealPath();
            if ($itemRealPath === false) continue;

            $itemRelativeUserPath = ltrim(str_replace(realpath($baseUserPath), '', $itemRealPath), DIRECTORY_SEPARATOR);
            $itemRelativeUserPathUrl = str_replace(DIRECTORY_SEPARATOR, '/', $itemRelativeUserPath);

            if ($fileInfo->isDir()) {
                $directories[] = [
                    'name' => $itemName,
                    'path_for_link' => $itemRelativeUserPathUrl,
                ];
            } elseif ($fileInfo->isFile()) {
                $extension = strtolower($fileInfo->getExtension());
                if (in_array($extension, $allowedImageExtensions)) {
                    $files[] = [
                        'name' => $itemName,
                        'url' => rtrim($baseUserUrl, '/') . '/' . $itemRelativeUserPathUrl,
                        'path_for_js' => $itemRelativeUserPathUrl,
                    ];
                }
            }
        }
    } catch (Exception $e) {
        error_log("Error al leer directorio {$path}: " . $e->getMessage());
    }
    usort($directories, fn($a, $b) => strtolower($a['name']) <=> strtolower($b['name']));
    usort($files, fn($a, $b) => strtolower($a['name']) <=> strtolower($b['name']));
    return ['directories' => $directories, 'files' => $files];
}

function getGeneralGalleryImagesFromDB_ib(string $generalGalleryBaseUrl, int $offset = 0, int $limit = 32): array {
    $imageData = ['images' => [], 'has_more' => false, 'new_offset' => $offset];
    $db = get_general_gallery_db_connection(); // Usa la función de extdata.php

    if (!$db) {
        error_log("General Gallery DB Error (ibrowser): No hay conexión a la base de datos.");
        return $imageData;
    }
    try {
        $totalStmt = $db->query('SELECT COUNT(id) as total FROM general_images');
        $totalImages = (int)($totalStmt->fetchColumn() ?: 0);

        if ($totalImages === 0 || $offset >= $totalImages) {
            $imageData['has_more'] = false;
            $imageData['new_offset'] = $offset;
            return $imageData;
        }
        $stmt = $db->prepare('SELECT filename, title, alt_text, filepath FROM general_images ORDER BY date_added DESC, filename COLLATE NOCASE ASC LIMIT :limit OFFSET :offset');
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        $results = $stmt->fetchAll();

        foreach ($results as $row) {
            $filePathSegment = ($row['filepath'] ? rtrim($row['filepath'],'/\\') . '/' : '');
            $imageData['images'][] = [
                'name' => $row['filename'],
                'alt_text' => $row['alt_text'] ?? $row['filename'],
                'title_text' => $row['title'] ?? $row['filename'],
                'url' => rtrim($generalGalleryBaseUrl, '/') . '/' . $filePathSegment . rawurlencode($row['filename']),
                'path_for_js' => $filePathSegment . $row['filename'],
            ];
        }
        $imageData['new_offset'] = $offset + count($results);
        $imageData['has_more'] = $imageData['new_offset'] < $totalImages;
    } catch (PDOException $e) {
        error_log("General Gallery DB Query Error (ibrowser): " . $e->getMessage());
    }
    return $imageData;
}

if (isset($_GET['action']) && $_GET['action'] === 'load_general_images') {
    $ajaxTokenPayload = verify_ibrowser_access_token($_GET['access_token'] ?? null);
    if ($ajaxTokenPayload === null) {
        http_response_code(403);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Acceso Denegado para AJAX. Token inválido.']);
        exit;
    }
    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 32;
    $generalImagesData = getGeneralGalleryImagesFromDB_ib(GENERAL_GALLERY_URL_IB, $offset, $limit);
    header('Content-Type: application/json');
    echo json_encode($generalImagesData);
    exit;
}

$initialBatchSize = 32;
$initialGeneralImagesData = getGeneralGalleryImagesFromDB_ib(GENERAL_GALLERY_URL_IB, 0, $initialBatchSize);
$generalImages = $initialGeneralImagesData['images'];
$generalImagesHasMore = $initialGeneralImagesData['has_more'];
$generalImagesNextOffset = $initialGeneralImagesData['new_offset'];

$userGalleryContents = getDirectoryContents_ib($currentFullPath_ib, CURRENT_USER_GALLERY_PHYSICAL_PATH_IB, CURRENT_USER_GALLERY_URL_IB);
$parentPathForLink_ib = null;
if (!empty($currentRelativePath_ib)) {
    $parentPathParts = explode(DIRECTORY_SEPARATOR, $currentRelativePath_ib);
    array_pop($parentPathParts);
    $parentPathForLink_ib = str_replace(DIRECTORY_SEPARATOR, '/', implode(DIRECTORY_SEPARATOR, $parentPathParts));
}
$js_user_image_base_url = rtrim(CURRENT_USER_GALLERY_URL_IB, '/') . '/';
$js_general_image_base_url = rtrim(GENERAL_GALLERY_URL_IB, '/') . '/';

?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Pragma" content="no-cache">
        <title>iFmup - Navegador de Imágenes</title>
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        <link rel="stylesheet" href="css/modern_ibrowser_style.css">
        <style>
            .ifmup-gallery-tabs { display: flex; flex-direction: column; height: 100%; }
            .tab-nav { list-style: none; padding: 0; margin: 0; display: flex; border-bottom: 1px solid #dee2e6; flex-shrink: 0; }
            .tab-nav .tab-link { padding: 10px 15px; cursor: pointer; border: 1px solid transparent; border-bottom: none; margin-bottom: -1px; background-color: #f8f9fa; color: #495057; border-top-left-radius: 0.25rem; border-top-right-radius: 0.25rem; }
            .tab-nav .tab-link.active { background-color: #fff; border-color: #dee2e6 #dee2e6 #fff; font-weight: 600; color: #007bff; }
            .tab-nav .tab-link:not(.active):hover { background-color: #e9ecef; }
            .tab-nav .tab-link .fas { margin-right: 0.5em; }
            .tab-content-container { flex-grow: 1; overflow: hidden; position: relative;}
            .tab-content { display: none; padding: 10px; height: 100%; overflow-y: auto; }
            .tab-content.active { display: block; }
        </style>
    </head>
    <body>
        <header class="ifmup-header">
            <nav>
                <ul>
                    <li><a href="fileupload.php?access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>" title="Subir Imágenes"><i class="fas fa-upload"></i> <span>Subir</span></a></li>
                    <li><a href="ibrowser.php?access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>" title="Galería de Imágenes" class="active"><i class="fas fa-images"></i> <span>Galería</span></a></li>
                    <li><a href="about.php?access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>" title="Acerca de..."><i class="fas fa-info-circle"></i> <span>Acerca</span></a></li>
                </ul>
            </nav>
        </header>
        <main class="ifmup-container">
            <aside class="ifmup-sidebar">
                <div class="ifmup-gallery-tabs">
                    <ul class="tab-nav">
                        <li class="tab-link active" data-tab="generalGalleryTab"><i class="fas fa-globe-americas"></i> Galería General</li>
                        <li class="tab-link" data-tab="userGalleryTab"><i class="fas fa-user-circle"></i> Tu Galería</li>
                    </ul>

                    <div class="tab-content-container">
                        <div id="generalGalleryTab" class="tab-content active">
                            <h4>Imágenes Compartidas</h4>
                            <div id="generalImageThumbnailList" class="image-thumbnail-list general-image-list-scrollable">
                                <?php if (empty($generalImages)): ?>
                                    <p class="no-files-message">No hay imágenes en la galería general.</p>
                                <?php endif; ?>
                                <?php foreach ($generalImages as $file): ?>
                                    <img src="<?php echo htmlspecialchars($file['url']); ?>"
                                        alt="<?php echo htmlspecialchars($file['alt_text']); ?>"
                                        title="<?php echo htmlspecialchars($file['title_text']); ?>"
                                        data-full-url="<?php echo htmlspecialchars($file['url']); ?>"
                                        data-gallery-type="general"
                                        onclick="showimgGeneral('<?php echo htmlspecialchars($file['url'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($file['name'], ENT_QUOTES, 'UTF-8'); ?>')">
                                <?php endforeach; ?>
                            </div>
                            <div id="generalGalleryLoading" class="loading-indicator" style="display: none;">
                                <i class="fas fa-spinner fa-spin"></i> Cargando más imágenes...
                            </div>
                            <?php if (!$generalImagesHasMore && !empty($generalImages)): ?>
                                <p id="noMoreGeneralImagesMessage" class="no-more-files-message">No hay más imágenes.</p>
                            <?php endif; ?>
                        </div>
                        <div id="userGalleryTab" class="tab-content">
                            <h4>Galería de <?php echo htmlspecialchars($userContextFromToken); ?></h4>
                            <div class="current-path">
                                <strong>Directorio:</strong> <?php echo htmlspecialchars($currentDisplayPath_ib === '' ? '/' : $currentDisplayPath_ib); ?>
                            </div>
                            <ul class="directory-list">
                                <?php if ($parentPathForLink_ib !== null): ?>
                                    <li><a href="?dir=<?php echo urlencode($parentPathForLink_ib); ?>&amp;access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>"><i class="fas fa-arrow-up"></i> ...Subir Nivel</a></li>
                                <?php endif; ?>
                                <?php foreach ($userGalleryContents['directories'] as $dir): ?>
                                    <li><a href="?dir=<?php echo urlencode($dir['path_for_link']); ?>&amp;access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>"><i class="fas fa-folder"></i> <?php echo htmlspecialchars($dir['name']); ?></a></li>
                                <?php endforeach; ?>
                            </ul>
                            <div class="image-thumbnail-list user-image-list">
                                <?php if (empty($userGalleryContents['files']) && empty($userGalleryContents['directories']) && $parentPathForLink_ib === null && ($currentDisplayPath_ib === '/' || $currentDisplayPath_ib === '')): ?>
                                    <p class="no-files-message">Tu galería está vacía.</p>
                                <?php elseif (empty($userGalleryContents['files']) && (!empty($currentDisplayPath_ib) && $currentDisplayPath_ib !== '/') && empty($userGalleryContents['directories'])): ?>
                                    <p class="no-files-message">No hay imágenes en esta carpeta.</p>
                                <?php endif; ?>
                                <?php foreach ($userGalleryContents['files'] as $file): ?>
                                    <img src="<?php echo htmlspecialchars($file['url']); ?>"
                                        alt="<?php echo htmlspecialchars($file['name']); ?>"
                                        title="<?php echo htmlspecialchars($file['name']); ?>"
                                        data-path-for-js="<?php echo htmlspecialchars($file['path_for_js']); ?>"
                                        data-gallery-type="user"
                                        onclick="showimgUser('<?php echo htmlspecialchars($file['path_for_js'], ENT_QUOTES, 'UTF-8'); ?>')">
                                <?php endforeach; ?>
                            </div>
                        </div>

                    </div>
                </div>
            </aside>
            <section class="ifmup-preview-pane">
                <div class="preview-container">
                    <img id="thumbimg" src="images/noPop.gif" alt="Vista previa de la imagen">
                </div>
                <form id="imageDetailsForm" class="image-form" onsubmit="return false;">
                    <div class="form-group">
                        <label for="surce">Fuente (Ruta/URL):</label>
                        <input type="text" id="surce" name="surce" readonly>
                    </div>
                    <div class="form-group">
                        <label for="alt">Texto Alternativo:</label>
                        <input type="text" id="alt" name="alt">
                    </div>
                    <div class="form-group dimensions">
                        <div>
                            <label for="width">Ancho (px):</label>
                            <input type="number" id="width" name="width" readonly>
                        </div>
                        <div>
                            <label for="height">Alto (px):</label>
                            <input type="number" id="height" name="height" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="border">Borde (px):</label>
                        <input type="number" id="border" name="border" value="0" readonly>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn-insert" onclick="sendSelectedImageDataToEditor()">
                            <i class="fas fa-check-circle"></i> Seleccionar esta Imagen
                        </button>
                    </div>
                </form>
            </section>
        </main>
        <script type="text/javascript">
            const JS_USER_IMAGE_BASE_URL = "<?php echo htmlspecialchars($js_user_image_base_url, ENT_QUOTES, 'UTF-8'); ?>";
            const generalImageListScrollContainer = document.getElementById('generalImageThumbnailList');
            const generalGalleryLoadingEl = document.getElementById('generalGalleryLoading');
            const noMoreGeneralImagesMessageEl = document.getElementById('noMoreGeneralImagesMessage');
            let isLoadingGeneralImages = false;
            let hasMoreGeneralImages = <?php echo json_encode($generalImagesHasMore); ?>;
            let nextGeneralImagesOffset = <?php echo json_encode($generalImagesNextOffset); ?>;
            const generalImagesBatchSizeJS = <?php echo $initialBatchSize; ?>;
            const validAccessTokenForJS = "<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>";

            function getEditorOriginFromUrl() {
                try {
                    const urlParams = new URLSearchParams(window.location.search);
                    const originFromParam = urlParams.get('editorOrigin');
                    if (originFromParam) {
                        const currentSelfOrigin = window.location.protocol + '//' + window.location.host;
                        const knownAllowedOrigins = [currentSelfOrigin];
                        try {
                            const parsedOriginFromParam = new URL(originFromParam);
                            if (parsedOriginFromParam.protocol + '//' + parsedOriginFromParam.host === currentSelfOrigin) {
                                return originFromParam;
                            }
                            if (knownAllowedOrigins.includes(originFromParam)){ return originFromParam; }
                        } catch(eUrl) { console.warn("iBrowser: editorOrigin '"+originFromParam+"' no es una URL válida."); return null; }
                        console.warn("iBrowser: El editorOrigin ('" + originFromParam + "') no está permitido."); return null;
                    }
                } catch (e) { console.error("iBrowser: Error al parsear editorOrigin de la URL:", e); }
                console.warn("iBrowser: editorOrigin no encontrado en la URL."); return null;
            }

            function extractFileName(path) {
                var name = path.substring(path.lastIndexOf('/') + 1);
                return name.substring(0, name.lastIndexOf('.')) || name;
            }

            function showimgUser(relativePathForJs) {
                var fullImageUrl = JS_USER_IMAGE_BASE_URL + relativePathForJs;
                var img = new Image();
                img.onload = function() {
                    document.getElementById('surce').value = relativePathForJs;
                    document.getElementById('width').value = this.width; document.getElementById('height').value = this.height;
                    document.getElementById('border').value = "0"; document.getElementById('alt').value = extractFileName(relativePathForJs);
                    document.getElementById('imageDetailsForm').dataset.galleryType = 'user';
                    var previewImg = document.getElementById('thumbimg'); previewImg.src = fullImageUrl;
                    previewImg.style.maxHeight = '250px'; previewImg.style.maxWidth = '100%'; previewImg.style.width = 'auto'; previewImg.style.height = 'auto';
                };
                img.onerror = function() { document.getElementById('thumbimg').src = 'images/noPop.gif'; };
                img.src = fullImageUrl;
            }

            function showimgGeneral(fullUrl, imageNameForAlt) {
                var img = new Image();
                img.onload = function() {
                    document.getElementById('surce').value = fullUrl;
                    document.getElementById('width').value = this.width; document.getElementById('height').value = this.height;
                    document.getElementById('border').value = "0"; document.getElementById('alt').value = extractFileName(imageNameForAlt);
                    document.getElementById('imageDetailsForm').dataset.galleryType = 'general';
                    var previewImg = document.getElementById('thumbimg'); previewImg.src = fullUrl;
                    previewImg.style.maxHeight = '250px'; previewImg.style.maxWidth = '100%'; previewImg.style.width = 'auto'; previewImg.style.height = 'auto';
                };
                img.onerror = function() { document.getElementById('thumbimg').src = 'images/noPop.gif'; };
                img.src = fullUrl;
            }

            function sendSelectedImageDataToEditor() {
                var pathOrUrlFromSurce = document.getElementById('surce').value;
                if (pathOrUrlFromSurce === '') { alert('Por favor, selecciona una imagen.'); return; }
                var galleryType = document.getElementById('imageDetailsForm').dataset.galleryType || 'user';
                var finalImageUrl;
                if (galleryType === 'general') {
                    finalImageUrl = pathOrUrlFromSurce;
                } else {
                    finalImageUrl = JS_USER_IMAGE_BASE_URL + pathOrUrlFromSurce;
                }
                var returnData = {
                    src: finalImageUrl, width: document.getElementById('width').value, height: document.getElementById('height').value,
                    alt: document.getElementById('alt').value, border: document.getElementById('border').value,
                    action: '', className: '', caption: 0, captionText: '', captionClass: ''
                };
                var targetOriginForPost = getEditorOriginFromUrl();
                if (!targetOriginForPost) {
                    alert("Error de configuración de seguridad: No se pudo determinar el origen del editor."); return;
                }
                if (window.parent && typeof window.parent.postMessage === 'function') {
                    window.parent.postMessage({ mceAction: 'ibrowserReturnData', data: returnData }, targetOriginForPost);
                } else { console.error("iBrowser: No se pudo comunicar con la ventana padre."); }
            }

            function loadMoreGeneralImages() {
                if (isLoadingGeneralImages || !hasMoreGeneralImages) return;
                isLoadingGeneralImages = true;
                if(generalGalleryLoadingEl) generalGalleryLoadingEl.style.display = 'block';
                if(noMoreGeneralImagesMessageEl) noMoreGeneralImagesMessageEl.style.display = 'none';

                const params = new URLSearchParams({
                    action: 'load_general_images', access_token: validAccessTokenForJS,
                    offset: nextGeneralImagesOffset, limit: generalImagesBatchSizeJS
                });

                fetch('ibrowser.php?' + params.toString())
                .then(response => {
                    isLoadingGeneralImages = false;
                    if(generalGalleryLoadingEl && hasMoreGeneralImages) generalGalleryLoadingEl.style.display = 'none';
                    if (!response.ok) throw new Error('Respuesta de red no fue OK: ' + response.statusText + ' - ' + response.url);
                    return response.json();
                })
                .then(data => {
                    if (data.error) {
                        console.error("Error AJAX cargando imágenes generales:", data.error);
                        hasMoreGeneralImages = false;
                        if(generalGalleryLoadingEl) generalGalleryLoadingEl.innerHTML = '<i class="fas fa-exclamation-circle"></i> Error al cargar.';
                        return;
                    }
                    if(data.images.length > 0 && generalImageListScrollContainer.querySelector('.no-files-message')) {
                        generalImageListScrollContainer.querySelector('.no-files-message').remove();
                    }
                    data.images.forEach(file => {
                        const imgElem = document.createElement('img');
                        imgElem.src = file.url; imgElem.alt = file.alt_text; imgElem.title = file.title_text;
                        imgElem.dataset.fullUrl = file.url; imgElem.dataset.galleryType = "general";
                        imgElem.onclick = function() { showimgGeneral(file.url, file.name); };
                        if(generalImageListScrollContainer) generalImageListScrollContainer.appendChild(imgElem);
                    });
                    hasMoreGeneralImages = data.has_more;
                    nextGeneralImagesOffset = data.new_offset;
                    if (!hasMoreGeneralImages && generalGalleryLoadingEl) {
                        generalGalleryLoadingEl.style.display = 'none'; // Ocultar spinner
                        if(noMoreGeneralImagesMessageEl) noMoreGeneralImagesMessageEl.style.display = 'block'; // Mostrar "no más imágenes"
                    }
                })
                .catch(error => {
                    console.error('Excepción AJAX al cargar más imágenes generales:', error);
                    if(generalGalleryLoadingEl) {
                        generalGalleryLoadingEl.style.display = 'block';
                        generalGalleryLoadingEl.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error de conexión.';
                    }
                    isLoadingGeneralImages = false; hasMoreGeneralImages = false;
                });
            }

            if (generalImageListScrollContainer) {
                generalImageListScrollContainer.addEventListener('scroll', function() {
                    if ((this.scrollTop + this.clientHeight >= this.scrollHeight - 200) && hasMoreGeneralImages && !isLoadingGeneralImages) {
                        loadMoreGeneralImages();
                    }
                });
            }

            document.querySelectorAll('.tab-nav .tab-link').forEach(button => {
                button.addEventListener('click', () => {
                    document.querySelectorAll('.tab-nav .tab-link').forEach(btn => btn.classList.remove('active'));
                    document.querySelectorAll('.ifmup-gallery-tabs .tab-content').forEach(content => content.classList.remove('active'));
                    button.classList.add('active');
                    const tabId = button.dataset.tab;
                    const activeTabContent = document.getElementById(tabId);
                    if (activeTabContent) {
                        activeTabContent.classList.add('active');
                    }
                    if (tabId === 'generalGalleryTab' && generalImageListScrollContainer && generalImageListScrollContainer.children.length <=1 && hasMoreGeneralImages && !isLoadingGeneralImages) {
                        // Si es la primera vez que se activa y está vacía (o solo tiene el mensaje de 'no hay')
                        if(generalImageListScrollContainer.querySelector('.no-files-message') && <?php echo json_encode(empty($generalImages)); ?>){
                            loadMoreGeneralImages();
                        }
                    }
                });
            });
            if(<?php echo json_encode(empty($generalImages)); ?> && hasMoreGeneralImages && document.querySelector('.tab-nav .tab-link[data-tab="generalGalleryTab"].active')) {
                // loadMoreGeneralImages(); // Considerar si cargar al inicio si la pestaña general está activa y vacía.
            }

        </script>
    </body>
</html>