<?php
declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0');

if (function_exists('session_status') && session_status() === PHP_SESSION_NONE) {
    // Aunque no usamos $_SESSION para el flujo principal, CSRF via session es una opción común.
    // Si se opta por Double Submit Cookie puramente, session_start puede no ser estrictamente necesario aquí
    // a menos que otra parte de la app lo requiera. Para el Double Submit Cookie, PHP necesita poder SETEAR la cookie.
    // Por ahora, lo mantenemos por si el CSRF token se guardara en sesión en `upload.php` para comparar,
    // pero el patrón double submit estricto no lo necesitaría en `upload.php` para almacenar el token.
    // Sin embargo, para generar un token CSRF único por carga de página, a veces se usa la sesión.
    // Si el token CSRF que se pone en la cookie y en el campo es el mismo y aleatorio cada vez,
    // no se necesita sesión para *generarlo* aquí. Lo quitaré por ahora para adherir al "no session".
    // El token CSRF se generará y se pondrá en la cookie y el campo.
}

require_once __DIR__ . '/extdata.php';

$accessToken = $_GET['access_token'] ?? $_POST['access_token'] ?? null;
$tokenPayload = verify_ibrowser_access_token($accessToken);

if ($tokenPayload === null) {
    http_response_code(403);
    die('Acceso Denegado. El token de acceso es inválido, ha expirado o no se proporcionó.');
}
$validAccessTokenForLinks = $accessToken;
$userContextFromToken = $tokenPayload['ctx'];

$protocol_fu = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
$host_fu = $_SERVER['HTTP_HOST'] ?? 'localhost';

$currentUserGalleryPhysicalPath_fu = rtrim(USER_GALLERIES_BASE_PHYSICAL, '/\\') . DIRECTORY_SEPARATOR . $userContextFromToken;
// $currentUserGalleryUrl_fu = $protocol_fu . '://' . $host_fu . rtrim(USER_GALLERIES_BASE_URL, '/') . '/' . $userContextFromToken; // No se usa directamente en esta página

if (!is_dir($currentUserGalleryPhysicalPath_fu)) {
    if (!@mkdir($currentUserGalleryPhysicalPath_fu, 0755, true) && !is_dir($currentUserGalleryPhysicalPath_fu)) {
        http_response_code(500);
        die('Error: No se pudo crear el directorio de la galería del usuario: ' . htmlspecialchars($userContextFromToken));
    }
}

$csrfTokenValue = bin2hex(random_bytes(32));
$cookie_options_fu = [
    'expires' => time() + 3600, 
    'path' => dirname($_SERVER['PHP_SELF']) ?: '/',
    'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
    'httponly' => true, 
    'samesite' => 'Lax'
];
setcookie('csrf_form_token_fu', $csrfTokenValue, $cookie_options_fu);

$currentDisplayPathForUpload = htmlspecialchars($userContextFromToken);

function listDirectSubdirectories_fu(string $basePath, string $userDirNameForDisplay): array {
    $subdirs = [];
    try {
        if (!is_dir($basePath) || !is_readable($basePath)) return [];
        $iterator = new DirectoryIterator($basePath);
        foreach ($iterator as $fileInfo) {
            if ($fileInfo->isDot() || !$fileInfo->isDir()) continue;
            $subdirs[] = [
                'name' => $fileInfo->getFilename(),
                'relative_path_value' => $fileInfo->getFilename(), 
                'display_name' => $userDirNameForDisplay . '/' . $fileInfo->getFilename(),
            ];
        }
    } catch (Exception $e) {
        error_log("FileUpload: Error listando subdirectorios en {$basePath}: " . $e->getMessage());
    }
    usort($subdirs, fn($a, $b) => strtolower((string)$a['name']) <=> strtolower((string)$b['name']));
    return $subdirs;
}
$destinationUserSubfolders = listDirectSubdirectories_fu($currentUserGalleryPhysicalPath_fu, $userContextFromToken);

$upload_max_filesize = ini_get('upload_max_filesize');
$post_max_size = ini_get('post_max_size');
$max_file_uploads = ini_get('max_file_uploads');
$memory_limit = ini_get('memory_limit');
$max_execution_time = ini_get('max_execution_time');

$displayableMessages_fu = [];
if (isset($_GET['status_count']) && is_numeric($_GET['status_count'])) {
    $messageCount = (int)$_GET['status_count'];
    for ($i = 0; $i < $messageCount; $i++) {
        if (isset($_GET['msg_type_'.$i]) && isset($_GET['msg_text_'.$i])) {
            $displayableMessages_fu[] = [
                'type' => htmlspecialchars($_GET['msg_type_'.$i]),
                'text' => htmlspecialchars($_GET['msg_text_'.$i])
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="Pragma" content="no-cache">
        <title>iFmup - Carga de Archivos</title>
        <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        <link rel="stylesheet" href="css/modern_ibrowser_style.css">
        <style>
            .upload-steps { list-style: none; padding: 0; counter-reset: step-counter; }
            .upload-steps > li {
                padding: 1.5rem;
                margin-bottom: 1rem;
                background-color: #fff;
                border: 1px solid #e9ecef;
                border-radius: 0.3rem;
                box-shadow: 0 1px 2px rgba(0,0,0,0.05);
            }
            .upload-steps > li::before {
                counter-increment: step-counter;
                content: counter(step-counter);
                font-size: 1.5em;
                font-weight: bold;
                color: #fff;
                background-color: #007bff;
                border-radius: 50%;
                width: 2.5rem;
                height: 2.5rem;
                line-height: 2.5rem;
                text-align: center;
                display: inline-block;
                margin-right: 1rem;
                float: left;
            }
            .upload-steps > li h3 { margin-top: 0.25rem; font-size: 1.25rem; color: #343a40;}
            .upload-steps > li .step-content { margin-left: 3.5rem; padding-top: 0.1rem; clear: left;}
            .destination-radio-group label { display: block; margin-bottom: 0.5rem; cursor: pointer; padding: 0.5rem; border-radius: 0.2rem;}
            .destination-radio-group label:hover { background-color: #f8f9fa; }
            .destination-radio-group input[type="radio"] { margin-right: 0.5em; vertical-align: middle; }
            .destination-radio-group .fas { margin-right: 0.3em; vertical-align: middle; color: #6c757d;}
            .destination-radio-group .fa-globe-americas {color: #28a745;}
            .destination-radio-group .fa-user-circle {color: #17a2b8;}
            .destination-radio-group .fa-folder {color: #ffc107;}
            .folder-management-panel { margin-top: 2rem; }
            .upload-steps > li::after { content: ""; display: table; clear: both; } /* Clearfix for floated ::before */
            #uploading {
                display: none; /* Oculto inicialmente */
                font-size: 18px;
                font-weight: bold;
                color: #007bff;
            }

        </style>
    </head>
    <body>
        <header class="ifmup-header">
            <nav>
                <ul>
                    <li><a href="fileupload.php?access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>" title="Subir Imágenes" class="active"><i class="fas fa-upload"></i> <span>Subir</span></a></li>
                    <li><a href="ibrowser.php?access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>&amp;editorOrigin=<?php echo htmlspecialchars($_GET['editorOrigin'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" title="Galería de Imágenes"><i class="fas fa-images"></i> <span>Galería</span></a></li>
                    <li><a href="about.php?access_token=<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>" title="Acerca de..."><i class="fas fa-info-circle"></i> <span>Acerca</span></a></li>
                </ul>
            </nav>
        </header>

        <main class="ifmup-container ifmup-upload-page">
            <?php if (!empty($displayableMessages_fu)): ?>
                <div class="messages-container">
                    <?php foreach ($displayableMessages_fu as $msg): ?>
                        <div class="message message-<?php echo $msg['type']; ?>">
                            <strong><?php echo ucfirst($msg['type']); ?>:</strong> <?php echo $msg['text']; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form action="upload.php" method="POST" enctype="multipart/form-data" class="ifmup-form">
                <input type="hidden" name="access_token" value="<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="csrf_token_field" value="<?php echo htmlspecialchars($csrfTokenValue, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="action" value="upload_file">
                <input type="hidden" name="user_subfolder_path" id="user_subfolder_path_hidden" value="">


                <ul class="upload-steps">
                    <li>
                        <h3><i class="fas fa-map-marker-alt"></i> Elegir Destino</h3>
                        <div class="step-content destination-radio-group">
                            <label title="Subir a la galería compartida por todos los usuarios">
                                <input type="radio" name="destination_gallery_type" value="general" checked>
                                <i class="fas fa-globe-americas"></i> Galería General (Compartida)
                            </label>
                            <label title="Subir a la raíz de tu galería personal (/<?php echo $currentDisplayPathForUpload; ?>)">
                                <input type="radio" name="destination_gallery_type" value="user_root">
                                <i class="fas fa-user-circle"></i> Mi Galería (Raíz: /<?php echo $currentDisplayPathForUpload; ?>)
                            </label>
                            <?php foreach ($destinationUserSubfolders as $folder): ?>
                                <label title="Subir a la subcarpeta /<?php echo htmlspecialchars($folder['display_name'], ENT_QUOTES, 'UTF-8'); ?> de tu galería personal">
                                    <input type="radio" name="destination_gallery_type" value="user_subfolder" data-subfolder-path="<?php echo htmlspecialchars($folder['relative_path_value'], ENT_QUOTES, 'UTF-8'); ?>">
                                    <i class="fas fa-folder"></i> Mi Galería / <?php echo htmlspecialchars($folder['name'], ENT_QUOTES, 'UTF-8'); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </li>

                    <li>
                        <h3><i class="fas fa-photo-video"></i> Seleccionar Archivos</h3>
                        <div class="step-content">
                            <div class="form-group">
                                <label for="archivos_upload">Archivos a subir:</label>
                                <input type="file" id="archivos_upload" name="archivos[]" required multiple accept="image/jpeg,image/png,image/gif,image/webp,image/avif">
                                <small>
                                    Permitidos: JPG, PNG, GIF, WEBP, AVIF. <br>
                                    Límite por archivo: <?php echo htmlspecialchars($upload_max_filesize); ?>.
                                    Límite total por subida: <?php echo htmlspecialchars($post_max_size); ?>.
                                    Máx. archivos por subida: <?php echo htmlspecialchars($max_file_uploads); ?>.
                                </small>
                            </div>
                            <div class="form-group">
                                <label for="resize_max_dimension">Redimensionar (Ancho o Alto Máx. en Px, opcional):</label>
                                <input type="text" id="resize_max_dimension" name="resize_max_dimension" pattern="[0-9]*|=?" title="Solo números o el signo igual (=) para no redimensionar." placeholder="Ej: 800 (o = para no redimensionar)">
                                <small>Se aplicará a todas las imágenes subidas. Dejar vacío o usar '=' para no redimensionar.</small>
                            </div>
                        </div>
                    </li>

                    <li>
                        <h3><i class="fas fa-cloud-upload-alt"></i> Enviar</h3>
                        <div class="step-content form-actions">
                            <button id="submitButton" type="submit" class="btn-primary btn-upload"><i class="fas fa-cloud-upload-alt"></i> Cargar Archivos Seleccionados</button>
                            <div id="uploading">🔄 Cargando archivos...</div>

                        </div>
                    </li>
                </ul>
            </form>
            <script>
                document.querySelector('.ifmup-form').addEventListener('submit', function(event) {
                    let button = document.querySelector('.btn-upload'); 
                    let uploadingDiv = document.getElementById('uploading');

                    button.disabled = true; // Desactiva el botón
                    uploadingDiv.style.display = 'block'; // Muestra el mensaje de carga
                });
            </script>




            <section class="ifmup-panel folder-management-panel">
                <h2><i class="fas fa-folder-cog"></i> Gestionar Carpetas en Mi Galería (/<?php echo $currentDisplayPathForUpload; ?>)</h2>
                <form action="upload.php" method="POST" class="ifmup-form ifmup-form-inline">
                    <input type="hidden" name="access_token" value="<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="hidden" name="csrf_token_field" value="<?php echo htmlspecialchars($csrfTokenValue, ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="hidden" name="action" value="create_folder">
                    <input type="hidden" name="base_relative_path" value="">
                    <div class="form-group">
                        <label for="new_folder_name_user">Nombre Nueva Carpeta:</label>
                        <input type="text" id="new_folder_name_user" name="new_folder_name" required pattern="[a-zA-Z0-9_-]+" title="Solo letras (sin acentos), números, guiones y subguiones.">
                    </div>
                    <button type="submit" class="btn-primary"><i class="fas fa-plus-circle"></i> Crear en Mi Galería</button>
                </form>
                <hr style="margin: 1.5rem 0;">
                <h4>Eliminar subcarpetas de Mi Galería:</h4>
                <?php if (empty($destinationUserSubfolders)): ?>
                    <p class="no-files-message">No hay subcarpetas en tu galería para eliminar.</p>
                <?php else: ?>
                    <?php foreach ($destinationUserSubfolders as $folder): ?>
                        <form action="upload.php" method="POST" class="ifmup-form-inline destination-item" style="margin-bottom: 0.5rem; padding: 0.5rem; background-color: #f8f9fa; border-radius: 0.2rem;">
                            <input type="hidden" name="access_token" value="<?php echo htmlspecialchars($validAccessTokenForLinks, ENT_QUOTES, 'UTF-8'); ?>">
                            <input type="hidden" name="csrf_token_field" value="<?php echo htmlspecialchars($csrfTokenValue, ENT_QUOTES, 'UTF-8'); ?>">
                            <input type="hidden" name="action" value="delete_folder">
                            <input type="hidden" name="folder_to_delete_relative" value="<?php echo htmlspecialchars($folder['relative_path_value'], ENT_QUOTES, 'UTF-8'); ?>">
                            <input type="hidden" name="gallery_type_for_delete" value="user">
                            <span style="flex-grow:1;"><i class="fas fa-folder" style="color:#ffc107;"></i> /<?php echo htmlspecialchars($folder['display_name'], ENT_QUOTES, 'UTF-8'); ?></span>
                            <button type="submit" class="btn-danger btn-small" 
                                onclick="return confirm('¡ATENCIÓN! ¿Seguro que quieres BORRAR la carpeta \'<?php echo htmlspecialchars($folder['name'], ENT_QUOTES, 'UTF-8'); ?>\' y todo su contenido? Esta acción no se puede deshacer.');">
                                <i class="fas fa-trash-alt"></i> Borrar
                            </button>
                        </form>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>

            <div class="server-limits">
                <small>Límites del servidor: memory_limit: <?php echo htmlspecialchars($memory_limit); ?>, max_execution_time: <?php echo htmlspecialchars($max_execution_time); ?>s.</small>
            </div>
        </main>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const form = document.querySelector('form[action="upload.php"][enctype="multipart/form-data"]');
                if (form) {
                    const radios = form.querySelectorAll('input[name="destination_gallery_type"]');
                    const hiddenSubfolderPathInput = document.getElementById('user_subfolder_path_hidden');

                    radios.forEach(radio => {
                        radio.addEventListener('change', function() {
                            if (this.value === 'user_subfolder' && this.dataset.subfolderPath && hiddenSubfolderPathInput) {
                                hiddenSubfolderPathInput.value = this.dataset.subfolderPath;
                            } else if (hiddenSubfolderPathInput) {
                                hiddenSubfolderPathInput.value = '';
                            }
                        });
                    });

                    const checkedSubfolderRadio = form.querySelector('input[name="destination_gallery_type"][value="user_subfolder"]:checked');
                    if (checkedSubfolderRadio && checkedSubfolderRadio.dataset.subfolderPath && hiddenSubfolderPathInput) {
                        hiddenSubfolderPathInput.value = checkedSubfolderRadio.dataset.subfolderPath;
                    }
                }
            });
        </script>
    </body>
</html>